CREATE TABLE student(studentId int PRIMARY KEY NOT null AUTO_INCREMENT,studentName varchar(122),className varchar(122));

